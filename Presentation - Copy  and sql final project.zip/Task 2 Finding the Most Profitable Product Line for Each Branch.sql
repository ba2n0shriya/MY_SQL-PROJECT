select * from walmartsales;

WITH ProductLineProfit AS (
    SELECT 
        Branch,
        `Product line`,
        SUM(`gross income`) AS TotalGrossIncome,
        SUM(cogs) AS TotalCOGS,
         SUM(cogs) - SUM(`gross income`)  AS TotalProfit
    FROM 
        walmartsales
    GROUP BY 
        Branch, `Product line`
),
MaxProfit AS (
    SELECT 
        Branch,
        MAX(TotalProfit) AS MaxTotalProfit
    FROM 
        ProductLineProfit
    GROUP BY 
        Branch
)
SELECT 
    p.Branch,
    p.`Product line`,
    p.TotalGrossIncome,
    p.TotalCOGS,
    p.TotalProfit
FROM 
    ProductLineProfit p
JOIN 
    MaxProfit m ON p.Branch = m.Branch AND p.TotalProfit = m.MaxTotalProfit
ORDER BY 
    p.Branch;






