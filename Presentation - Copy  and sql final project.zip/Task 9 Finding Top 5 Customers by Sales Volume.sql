select * from walmartsales;

SELECT 
    `Invoice ID`,  -- Use the correct column name for customer identification
    SUM(`Total`) AS TotalSalesRevenue  -- Replace `Total` with the actual column name for sales amount
FROM 
    walmartsales
GROUP BY 
    `Invoice ID`
ORDER BY 
    TotalSalesRevenue DESC
LIMIT 5;
