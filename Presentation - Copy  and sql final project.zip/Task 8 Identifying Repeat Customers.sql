select * from walmartsales;

WITH CustomerPurchases AS (
    SELECT 
        `Invoice ID`,
        STR_TO_DATE(`Date`, '%Y-%m-%d') AS PurchaseDate  -- Convert text to date format
    FROM 
        walmartsales
),
RepeatPurchases AS (
    SELECT 
        cp1.`Invoice ID` AS FirstInvoiceID,
        COUNT(cp2.`Invoice ID`) AS RepeatOrderCount,  -- Count of repeated invoices
        COUNT(*) AS TotalOrdersWithin30Days  -- Count of all orders within 30 days
    FROM 
        CustomerPurchases cp1
    JOIN 
        CustomerPurchases cp2 
    ON 
        cp1.`Invoice ID` <> cp2.`Invoice ID`  -- Ensure we are comparing different invoices
        AND DATEDIFF(cp2.PurchaseDate, cp1.PurchaseDate) <= 30  -- Purchases within 30 days
    GROUP BY 
        cp1.`Invoice ID`
    HAVING 
        RepeatOrderCount > 0  -- Only include invoices with repeat purchases
)

SELECT 
    FirstInvoiceID,
    RepeatOrderCount,
    TotalOrdersWithin30Days  -- Include total orders within 30 days
FROM 
    RepeatPurchases
ORDER BY 
    RepeatOrderCount DESC;






