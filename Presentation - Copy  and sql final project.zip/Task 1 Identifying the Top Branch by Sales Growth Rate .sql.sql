select * from walmartsales;

show columns from walmartsales;


WITH MonthlySales AS (
    SELECT 
        Branch,
        DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') AS Month,
        SUM(Total) AS MonthlyTotalSales
    FROM 
        walmartsales
    GROUP BY 
        Branch, DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m')
),
MonthlyGrowth AS (
    SELECT 
        Branch,
        Month,
        MonthlyTotalSales,
        LAG(MonthlyTotalSales) OVER (PARTITION BY Branch ORDER BY Month) AS PreviousMonthSales,
        CASE 
            WHEN LAG(MonthlyTotalSales) OVER (PARTITION BY Branch ORDER BY Month) IS NULL THEN NULL
            WHEN LAG(MonthlyTotalSales) OVER (PARTITION BY Branch ORDER BY Month) = 0 THEN NULL
            ELSE (MonthlyTotalSales - LAG(MonthlyTotalSales) OVER (PARTITION BY Branch ORDER BY Month)) / 
                 LAG(MonthlyTotalSales) OVER (PARTITION BY Branch ORDER BY Month) * 100
        END AS GrowthRate
    FROM 
        MonthlySales
),
BranchAverageGrowth AS (
    SELECT 
        Branch,
        AVG(GrowthRate) AS AvgGrowthRate
    FROM 
        MonthlyGrowth
    WHERE 
        GrowthRate IS NOT NULL  -- Exclude null growth rates from average calculation
    GROUP BY 
        Branch
)
SELECT 
    Branch,
    AvgGrowthRate
FROM 
    BranchAverageGrowth
WHERE 
    AvgGrowthRate IS NOT NULL AND AvgGrowthRate <> 0  -- Only include branches with actual growth
ORDER BY 
    AvgGrowthRate DESC
LIMIT 1;
