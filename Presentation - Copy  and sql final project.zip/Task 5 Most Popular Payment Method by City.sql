select * from walmartsales;

WITH PaymentCounts AS (
    SELECT 
        `City`,
        `Payment`,
        COUNT(*) AS PaymentCount
    FROM 
        walmartsales
    GROUP BY 
        `City`, `Payment`
)

SELECT 
    pc1.`City`,
    pc1.`Payment` AS MostPopularPaymentMethod,
    pc1.PaymentCount
FROM 
    PaymentCounts pc1
JOIN (
    SELECT 
        `City`,
        MAX(PaymentCount) AS MaxPaymentCount
    FROM 
        PaymentCounts
    GROUP BY 
        `City`
) pc2 ON pc1.`City` = pc2.`City` AND pc1.PaymentCount = pc2.MaxPaymentCount
ORDER BY 
    pc1.`City`;

