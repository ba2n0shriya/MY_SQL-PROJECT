select * from walmartsales;

SELECT 
    DAYOFWEEK(STR_TO_DATE(`Date`, '%Y-%m-%d')) AS DayOfWeek,  
    CASE DAYOFWEEK(STR_TO_DATE(`Date`, '%Y-%m-%d'))
        WHEN 1 THEN 'Sunday'
        WHEN 2 THEN 'Monday'
        WHEN 3 THEN 'Tuesday'
        WHEN 4 THEN 'Wednesday'
        WHEN 5 THEN 'Thursday'
        WHEN 6 THEN 'Friday'
        WHEN 7 THEN 'Saturday'
    END AS DayName,
    SUM(`Total`) AS TotalSales
FROM 
    walmartsales
GROUP BY 
    DAYOFWEEK(STR_TO_DATE(`Date`, '%Y-%m-%d')),
    DayName  -- Include DayName in GROUP BY to avoid the error
ORDER BY 
    TotalSales DESC  -- Order by total sales in descending order
LIMIT 1;  -- Limit to get only the day with the highest sales


