select * from walmartsales;

WITH ProductLineSales AS (
    SELECT 
        `Product line`,
        `Customer type`,
        SUM(`gross income`) AS TotalSales  
    FROM 
        walmartsales
    GROUP BY 
        `Product line`, `Customer type`
)

SELECT 
    `Product line`,
    `Customer type`,
    TotalSales
FROM 
    ProductLineSales
ORDER BY 
    `Customer type`, TotalSales DESC;  
