select * from walmartsales;

WITH MonthlySales AS (
    SELECT 
        DATE_FORMAT(STR_TO_DATE(`Date`, '%Y-%m-%d'), '%Y-%m') AS SaleMonth,  
        `Gender`,
        SUM(`gross income`) AS TotalSales  
    FROM 
        walmartsales
    WHERE 
        STR_TO_DATE(`Date`, '%Y-%m-%d') IS NOT NULL  -- Filtering out any invalid dates
    GROUP BY 
        SaleMonth, `Gender`
)

SELECT 
    SaleMonth,
    `Gender`,
    TotalSales
FROM 
    MonthlySales
ORDER BY 
    SaleMonth, `Gender`;

