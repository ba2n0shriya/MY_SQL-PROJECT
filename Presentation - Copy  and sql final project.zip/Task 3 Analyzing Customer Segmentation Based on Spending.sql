select * from walmartsales;

WITH CustomerSpending AS (
    SELECT 
        `Invoice ID`,
        SUM(`gross income`) AS TotalPurchaseAmount
    FROM 
        walmartsales
    GROUP BY 
        `Invoice ID`
),
RankedSpending AS (
    SELECT 
        `Invoice ID`,
        TotalPurchaseAmount,
        ROW_NUMBER() OVER (ORDER BY TotalPurchaseAmount DESC) AS RowNum,
        COUNT(*) OVER () AS TotalCount
    FROM 
        CustomerSpending
),
SpendingThresholds AS (
    SELECT 
        MAX(TotalPurchaseAmount) AS HighThreshold,
        MAX(CASE 
                WHEN RowNum = FLOOR(TotalCount * 0.33) THEN TotalPurchaseAmount 
                ELSE NULL 
            END) AS MediumThreshold
    FROM 
        RankedSpending
),
CustomerSegmentation AS (
    SELECT 
        cs.`Invoice ID`,
        cs.TotalPurchaseAmount,
        CASE 
            WHEN cs.TotalPurchaseAmount >= (SELECT HighThreshold FROM SpendingThresholds) THEN 'High'
            WHEN cs.TotalPurchaseAmount >= (SELECT MediumThreshold FROM SpendingThresholds) THEN 'Medium'
            ELSE 'Low'
        END AS SpendingCategory
    FROM 
        CustomerSpending cs
)

SELECT 
    `Invoice ID`,
    TotalPurchaseAmount,
    SpendingCategory
FROM 
    CustomerSegmentation
ORDER BY 
    TotalPurchaseAmount DESC;




