select * from walmartsales;

show columns from walmartsales;

WITH ProductLineStats AS (
    SELECT 
        `Product line`,
        AVG(`gross income`) AS AvgGrossIncome,
        STDDEV(`gross income`) AS StdDevGrossIncome
    FROM 
        walmartsales
    GROUP BY 
        `Product line`
),
Anomalies AS (
    SELECT 
        ws.`Invoice ID`,
        ws.`Product line`,
        ws.`gross income`,
        ( (ws.`gross income` - pls.AvgGrossIncome) 
          / NULLIF(pls.StdDevGrossIncome, 0) ) AS GrossIncomeZScore,
        CASE 
            WHEN ABS((ws.`gross income` - pls.AvgGrossIncome) 
                     / NULLIF(pls.StdDevGrossIncome, 0)) > 2 THEN 'Anomaly'
            ELSE 'Normal'
        END AS AnomalyStatus
    FROM 
        walmartsales ws
    JOIN 
        ProductLineStats pls ON ws.`Product line` = pls.`Product line`
)

SELECT 
    `Invoice ID`,
    `Product line`,
    `gross income`,
    GrossIncomeZScore,
    AnomalyStatus
FROM 
    Anomalies
WHERE 
    AnomalyStatus = 'Anomaly'
ORDER BY 
    `Product line`, `gross income` DESC;




